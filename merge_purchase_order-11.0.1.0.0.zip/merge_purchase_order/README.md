Odoo 11.0 Community

Installation 
============
* Install the Application => Apps -> Merge Purchase Order (Technical Name: merge_purchase_order)



Merge Purchase Order
==================================
* Select the orders you want to merge with choices like merge and delete, merge and cancel,
  create new and cancel & create and delete.


Steps
=====
* Go to Purchase after installing the module and select the orders that you want to merge
 and click on action and click on merge orders.



